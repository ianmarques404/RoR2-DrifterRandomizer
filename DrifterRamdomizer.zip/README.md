Drifter Randomizer

This mod expands Drifter's 'Cleanup' skill item pool to include EVERY single projectile in the game(yes, every. single. one.).

Features

The 'Cleanup' skill (Drifter's Default Secondary) normally pulls from a small pool of junk items, this mod injects every registered projectile in the game into that pool.

This mod is about chaos and of course it's 0% balanced and prone to bugs or weird interactions, things will break.

Installation:

Install BepInExPack and R2API.

Drop DrifterRandomizer.dll into your BepInEx/plugins folder (or use r2modman).

Known Issues:

Some projectiles may be invisible or have weird physics because they weren't designed to be thrown by a player.
